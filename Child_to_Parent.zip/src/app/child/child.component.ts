import { Message } from '@angular/compiler/src/i18n/i18n_ast';
import { Component,EventEmitter,Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent
{
  @Output() public Myevent = new EventEmitter();
  public Message = "Hello Parent...";

  public SendMessage()
  {
    this.Myevent.emit(this.Message);
  }
}
