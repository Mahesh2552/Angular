export interface IBatches
{
    Name:String,
    Duration:number,
    Fees:number
}

//sequence should be same as in json