import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-batch-details',
  template: `<h2>Inside Courses-Details</h2>
  <ul *ngFor = "let value of Courses">
    <li>{{value.Name}} with duration {{value.Duration}} having fees {{value.Fees}}</li>
  </ul>
  `
})
export class BatchDetailsComponent implements OnInit 
{
  public Courses =[
    {"Name" : "IMCA","Duration":3,"Fees":50890},
    {"Name" : "CS","Duration":2,"Fees":25250},
    {"Name" : "MCA","Duration":2,"Fees":27500}
  ];

  constructor() { }

  ngOnInit(): void {
  }

}
