import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-batch-list',
  template: `<h2>Inside Courses-List<h2>
  <ul *ngFor = "let value of Courses">
    <li>{{value.Name}}</li>
  </ul>
  `
})
export class BatchListComponent implements OnInit 
{
  public Courses =[
    {"Name" : "IMCA","Duration":3,"Fees":50890},
    {"Name" : "CS","Duration":2,"Fees":25250},
    {"Name" : "MCA","Duration":2,"Fees":27500}
  ];

  constructor() { }

  ngOnInit(): void {
  }

}
